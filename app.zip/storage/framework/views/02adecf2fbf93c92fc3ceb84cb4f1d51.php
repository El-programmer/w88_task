<div class="p-1">
    <div class="card" style="width: 18rem;">
        <img src="<?php echo e($product->ImageUrl); ?>" class="card-img-top" alt="<?php echo e($product->title); ?>">
        <div class="card-body">
          <h5 class="card-title"><?php echo e($product->title); ?></h5>
          
          <a href="<?php echo e(route('products.show' , $product)); ?>" class="btn btn-primary">view</a>

          <span class="badge bg-secondary"><?php echo e($product->price); ?> USD</span>
        </div>
      </div>
</div>
<?php /**PATH C:\Users\Test\Desktop\task-app2\resources\views/site/products/card.blade.php ENDPATH**/ ?>