<?php $__env->startSection('content'); ?>


<h3><?php echo e($product->title); ?></h3>

<div class="row row-cols-sm-2">

<div>
    <img src="<?php echo e($product->imageUrl); ?>" class="card-img-top w-100" alt="<?php echo e($product->title); ?>">
</div>
<div>
    <p><?php echo $product->description; ?></p>
</div>

<span class="badge bg-secondary">    <?php echo e($product->price); ?> USD
</span>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Test\Desktop\task-app2\resources\views/site/products/show.blade.php ENDPATH**/ ?>