<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;

class ProuctTest extends TestCase
{
    public $url = "api/products";
    /**
     * A basic unit test example.
     */
    public function test_index_retuen_products(): void
    {
        $product = Product::faker(5)->create();
        $response = $this->get($this->url);
        $response->assertSuccessful();
        $this->assertTrue(true);
    }

     public function test_show(): void
    {
        $response = $this->get($this->url."/1");
        $response->assertSuccessful();
        $this->assertTrue(true);
    }


    public function test_create(): void
    {
        $data = [
            "title"=> "product 1",
            "description"=> "description product 1",
            "price"=> 100,
            "image" => $this->faker->image('public/storage' , 600,200),
        ];
        $response->postjson($this->url , $data);
        $this->assertTrue(true);
    }
    public function update_create(): void
    {
        $data = [
            "title"=> "product 1",
            "description"=> "description product 1",
            "price"=> 100,
            "image" => $this->faker->image('public/storage' , 600,200),
        ];
        $response->putjson($this->url,"/1" , $data);
        $this->assertTrue(true);
    }

    public function delete_create(): void
    {
        $response->delete($this->url,"/1" , $data);
        $this->assertTrue(203);
    }
}
